#!/bin/bash

cd /Users/benzativit/Desktop/Realtime/Quiz/quiz2_activity_regcognition
python sub_iot.py