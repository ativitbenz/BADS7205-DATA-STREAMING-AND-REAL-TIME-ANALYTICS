#!/bin/bash

cd /Users/benzativit/Desktop/Realtime/Quiz/quiz3-SpaceWars-master
python space_wars.py