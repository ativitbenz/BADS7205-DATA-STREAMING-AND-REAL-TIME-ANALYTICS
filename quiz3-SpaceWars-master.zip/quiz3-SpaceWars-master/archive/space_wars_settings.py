space_wars_settings.py

# Defining constants

MUSIC 		= True
GAME_SPEED 	= 5 		# 1 to 5
PLAYER_NAME	= 'DAN'
